@echo install DumpViewerCR start...
@echo.

set dir=%~dp0
set dir=%dir:\=\\%
set name=DumpViewerCR.exe
set path=%dir%%name%

rem Mouse right button for file
del  filemenu.reg

echo Windows Registry Editor Version 5.00>>filemenu.reg
echo.>>filemenu.reg
echo [HKEY_CLASSES_ROOT\*\shell\DumpViewerCR]>>filemenu.reg
echo "MUIVerb"="Open With DumpViewerCR">>filemenu.reg
echo "Icon"="%path%,0">>filemenu.reg
echo.>>filemenu.reg
echo [HKEY_CLASSES_ROOT\*\shell\DumpViewerCR\command]>>filemenu.reg
echo @="\"%path%\" \"%%l\"" >> filemenu.reg

c:\windows\regedit -s filemenu.reg

@echo.

rem Mouse right button for folder
del foldermenu.reg

echo Windows Registry Editor Version 5.00>>foldermenu.reg
echo.>>foldermenu.reg
echo [HKEY_CLASSES_ROOT\Folder\shell\DumpViewerCR]>>foldermenu.reg
echo "MUIVerb"="Open With DumpViewerCR">>foldermenu.reg
echo "Icon"="%path%,0">>foldermenu.reg
echo.>>foldermenu.reg
echo [HKEY_CLASSES_ROOT\Folder\shell\DumpViewerCR\command]>>foldermenu.reg
echo @="\"%path%\" \"%%l\"" >> foldermenu.reg

c:\windows\regedit -s foldermenu.reg

@echo.
@echo install DumpViewerCR successfully...
@echo.
@pause