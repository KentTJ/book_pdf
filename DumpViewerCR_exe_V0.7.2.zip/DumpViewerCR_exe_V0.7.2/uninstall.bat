@echo uninstall DumpViewerCR start...
@echo.

reg delete HKEY_CLASSES_ROOT\*\shell\DumpViewerCR /f
reg delete HKEY_CLASSES_ROOT\Folder\shell\DumpViewerCR /f


@echo.
@echo uninstall DumpViewerCR successfully...
@echo.
@pause